require('dotenv').config()
const server = require('./lib/server')

module.exports = server
